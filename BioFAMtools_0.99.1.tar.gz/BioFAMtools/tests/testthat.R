library(testthat)
library(BioFAMtools)

test_check("BioFAMtools")
