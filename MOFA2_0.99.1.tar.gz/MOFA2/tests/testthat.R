library(testthat)
library(MOFA2)

test_check("MOFA2")
