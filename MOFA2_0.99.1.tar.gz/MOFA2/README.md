# MOFA+ R package

MOFA+ R package provides functionality to load and interpret trained MOFA+ models as well as to create, prepare and train models from existing R objects.
